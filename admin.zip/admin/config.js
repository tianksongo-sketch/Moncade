/* Set this to the MAIN MOCA site (the Vercel project that serves /api/*). No trailing slash. */
window.MOCA_ADMIN_CONFIG = { apiBase: 'https://YOUR-MAIN-SITE.vercel.app' };
