/* Private admin client. Talks only to the backend (admin-feedback). All text is rendered with textContent, never innerHTML. */
(() => {
  const cfg = window.MOCA_ADMIN_CONFIG || {};
  const API = (cfg.apiBase || '').replace(/\/$/, '');
  const TOKEN_KEY = 'moca_admin_token';
  const $ = s => document.querySelector(s);
  const el = (tag, cls, text) => { const n = document.createElement(tag); if (cls) n.className = cls; if (text != null) n.textContent = text; return n; };

  let token = sessionStorage.getItem(TOKEN_KEY) || '';
  let filter = 'all', query = '', items = [], counts = { all: 0, new: 0, read: 0, done: 0 }, timer = null;

  $('#apiLabel').textContent = API ? 'Backend: ' + API : 'Backend belum diset (admin/config.js)';

  async function api(method, path = '', body) {
    const r = await fetch(API + '/api/admin-feedback' + path, {
      method, headers: { Authorization: 'Bearer ' + token, 'Content-Type': 'application/json' },
      body: body ? JSON.stringify(body) : undefined, credentials: 'omit', cache: 'no-store'
    });
    if (r.status === 401) { logout('Token salah atau sudah tidak berlaku.'); throw new Error('unauthorized'); }
    if (!r.ok) throw new Error('HTTP ' + r.status);
    return r.json();
  }

  function showLogin(msg) {
    $('#dashView').classList.add('hidden'); $('#loginView').classList.remove('hidden');
    $('#loginErr').textContent = msg || ''; $('#tokenInput').focus();
    document.title = 'MOCA · Feedback admin';
  }
  function showDash() {
    $('#loginView').classList.add('hidden'); $('#dashView').classList.remove('hidden');
    load(); startTimer();
  }
  function logout(msg) {
    token = ''; sessionStorage.removeItem(TOKEN_KEY); stopTimer();
    items = []; render(); showLogin(msg);
  }
  function startTimer() { stopTimer(); timer = setInterval(() => { if (!document.hidden) load(true); }, 30000); $('#liveDot').classList.add('on'); }
  function stopTimer() { if (timer) clearInterval(timer); timer = null; $('#liveDot').classList.remove('on'); }

  async function load(silent) {
    try {
      const data = await api('GET');
      items = data.items || []; counts = data.counts || counts;
      $('#status').textContent = 'Terakhir diperbarui ' + new Date().toLocaleTimeString('id-ID');
      render();
    } catch (e) {
      if (!silent && e.message !== 'unauthorized') $('#status').textContent = 'Gagal memuat data. Coba refresh.';
    }
  }

  function matches(i) {
    if (filter !== 'all' && i.status !== filter) return false;
    if (!query) return true;
    const hay = [i.message, i.game, i.contact, i.category, i.view].join(' ').toLowerCase();
    return hay.includes(query);
  }

  function render() {
    $('#cAll').textContent = counts.all; $('#cNew').textContent = counts.new;
    $('#cRead').textContent = counts.read; $('#cDone').textContent = counts.done;
    document.title = (counts.new ? '(' + counts.new + ') ' : '') + 'MOCA · Feedback admin';
    const list = $('#list'); list.textContent = '';
    const shown = items.filter(matches);
    if (!shown.length) { list.appendChild(el('p', 'dim empty', items.length ? 'Tidak ada yang cocok.' : 'Belum ada feedback masuk.')); return; }
    shown.forEach(i => list.appendChild(card(i)));
  }

  function card(i) {
    const box = el('article', 'item' + (i.status === 'new' ? ' new' : ''));
    const meta = el('div', 'meta');
    meta.appendChild(el('span', 'pill' + (i.status === 'new' ? ' new' : ''), i.status));
    meta.appendChild(el('span', 'pill', i.category || 'other'));
    if (i.game) meta.appendChild(el('span', 'pill', 'game: ' + i.game));
    if (i.view) meta.appendChild(el('span', '', 'tab: ' + i.view));
    meta.appendChild(el('span', '', new Date(i.createdAt).toLocaleString('id-ID')));
    box.appendChild(meta);
    box.appendChild(el('p', 'msg', i.message));
    if (i.contact) box.appendChild(el('p', 'contact', 'Kontak: ' + i.contact));

    const acts = el('div', 'acts');
    const act = (label, cls, fn) => { const b = el('button', 'btn ' + (cls || 'ghost'), label); b.type = 'button'; b.addEventListener('click', fn); acts.appendChild(b); };
    if (i.status !== 'read') act('TANDAI DIBACA', '', () => update(i.id, 'read'));
    if (i.status !== 'done') act('SELESAI', '', () => update(i.id, 'done'));
    if (i.status !== 'new') act('KEMBALI BARU', '', () => update(i.id, 'new'));
    act('SALIN', '', () => { if (navigator.clipboard) navigator.clipboard.writeText(i.message).catch(() => {}); });
    act('HAPUS', 'danger', () => remove(i.id));
    box.appendChild(acts);
    return box;
  }

  async function update(id, status) {
    try { await api('PATCH', '?id=' + encodeURIComponent(id), { id, status }); await load(); }
    catch (e) { if (e.message !== 'unauthorized') $('#status').textContent = 'Gagal mengubah status.'; }
  }
  async function remove(id) {
    if (!confirm('Hapus feedback ini permanen?')) return;
    try { await api('DELETE', '?id=' + encodeURIComponent(id)); await load(); }
    catch (e) { if (e.message !== 'unauthorized') $('#status').textContent = 'Gagal menghapus.'; }
  }

  $('#loginForm').addEventListener('submit', async e => {
    e.preventDefault();
    const t = $('#tokenInput').value.trim();
    if (!API) { $('#loginErr').textContent = 'Set apiBase dulu di admin/config.js.'; return; }
    if (t.length < 32) { $('#loginErr').textContent = 'Token terlalu pendek.'; return; }
    token = t;
    try { await api('GET'); sessionStorage.setItem(TOKEN_KEY, token); $('#tokenInput').value = ''; showDash(); }
    catch (err) { if (err.message !== 'unauthorized') $('#loginErr').textContent = 'Tidak bisa terhubung ke backend.'; token = ''; }
  });
  $('#logoutBtn').addEventListener('click', () => logout(''));
  $('#refreshBtn').addEventListener('click', () => load());
  $('#tabs').addEventListener('click', e => {
    const b = e.target.closest('button[data-f]'); if (!b) return;
    filter = b.dataset.f;
    document.querySelectorAll('#tabs button').forEach(x => x.classList.toggle('on', x === b));
    render();
  });
  $('#search').addEventListener('input', e => { query = e.target.value.trim().toLowerCase(); render(); });
  document.addEventListener('visibilitychange', () => { if (!document.hidden && token) load(true); });

  if (token) { api('GET').then(showDash).catch(() => showLogin('')); } else showLogin('');
})();
